package com.alibaba.dubbo.remoting.transport.http2.codec;

import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http2.*;

/**
 * Created By Rapharino on 2020/6/17 2:07 下午
 * <p>
 * http/2 connection
 */
public abstract class AbstractHttp2ConnectionHandler extends Http2ConnectionHandler {
    // initial connection window for flow control
    // @see https://laike9m.com/blog/rfc7540-bi-ji-wu-flow-control,106/
    private int initialConnectionWindow;
    // ch context
    private ChannelHandlerContext ctx;
    // connection Key
    protected final Http2Connection.PropertyKey connectionKey;

    public AbstractHttp2ConnectionHandler(
            Http2ConnectionDecoder decoder,
            Http2ConnectionEncoder encoder,
            Http2Settings initialSettings) {
        super(decoder, encoder, initialSettings);
        this.connectionKey = connection().newKey();
        this.initialConnectionWindow = initialSettings.initialWindowSize() == null ? -1 : initialSettings.initialWindowSize();
        // shutdown no timeout
        gracefulShutdownTimeoutMillis(-1);
    }

    @Override
    public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
        this.ctx = ctx;
        // Sends the connection preface if we haven't already.
        super.handlerAdded(ctx);
        sendInitialConnectionWindow();
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        // Sends connection preface if we haven't already.
        super.channelActive(ctx);
        if (connection().isServer()) {
            sendInitialConnectionWindow();
        }
    }

    protected final ChannelHandlerContext ctx() {
        return ctx;
    }

    /**
     * Sends initial connection window to the remote endpoint if necessary.
     */
    private void sendInitialConnectionWindow() throws Http2Exception {
        if (ctx.channel().isActive() && initialConnectionWindow > 0) {
            // current stream
            Http2Stream connectionStream = connection().connectionStream();
            int currentSize = connection().local().flowController().windowSize(connectionStream);
            int delta = initialConnectionWindow - currentSize;
            // increase window size by the window size
            decoder().flowController().incrementWindowSize(connectionStream, delta);
            initialConnectionWindow = -1;
            ctx.flush();
        }
    }
}