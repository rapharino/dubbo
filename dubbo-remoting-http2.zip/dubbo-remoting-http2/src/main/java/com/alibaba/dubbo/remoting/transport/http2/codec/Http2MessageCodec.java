package com.alibaba.dubbo.remoting.transport.http2.codec;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import io.netty.handler.codec.http2.*;
import io.netty.util.concurrent.GenericFutureListener;
import io.netty.util.concurrent.PromiseCombiner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created By Rapharino on 2020/7/1 5:01 下午
 * <p>
 * out bound handle to write/read message
 */
public abstract class Http2MessageCodec extends AbstractHttp2ConnectionHandler {

    private MessageListener listener;

    private final Logger logger = LoggerFactory.getLogger(Http2MessageCodec.class);

    private final Map<Integer, Http2Headers> headersByStreamId = new HashMap<>();

    /**
     * message listener (read/write)
     */
    interface MessageListener {

        void OnRead(ChannelHandlerContext ctx, Message message);

        void OnWrite(ChannelHandlerContext ctx, Message message);

    }

    public Http2MessageCodec(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings) {
        super(decoder, encoder, initialSettings);
        decoder().frameListener(new FrameListener());
    }

    private class FrameListener extends Http2FrameAdapter {

        @Override
        public void onHeadersRead(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int padding, boolean endStream) throws Http2Exception {
            // put
            headersByStreamId.put(streamId, headers);
            super.onHeadersRead(ctx, streamId, headers, padding, endStream);
        }

        @Override
        public int onDataRead(ChannelHandlerContext ctx, int streamId, ByteBuf data, int padding, boolean endOfStream) throws Http2Exception {
            if (endOfStream) {
                // get
                final Http2Headers headers = headersByStreamId.remove(streamId);
                // final ByteBuf data = data;
                //
                logger.info("channel read,header:{},data:{}", headers, data);
            } else {
                logger.error("not endOfStream");
            }
            return super.onDataRead(ctx, streamId, data, padding, endOfStream);
        }
    }

    @Override
    public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
        if (msg instanceof Message) {
            final Message message = ((Message) msg);
            int streamId = message.id();
            // maybe local ? (RequestMessage)
            if (isStreamIdValid(streamId)) {
                streamId = connection().local().incrementAndGetNextStreamId();
                if (streamId < 0) {
                    promise.setFailure(new Http2NoMoreStreamIdsException());
                    return;
                }
            }
            // header
            Http2Headers headers = prepareHeaders(message);
            ChannelPromise headersPromise = ctx().newPromise();
            ChannelPromise daraPromise = ctx().newPromise();
            encoder().writeHeaders(ctx(), streamId, headers, 0, false, headersPromise);
            encoder().writeData(ctx, streamId, message.data(), 0, true, daraPromise);
            final PromiseCombiner promiseCombiner = new PromiseCombiner();
            // 合并: 因为 任意 header 和 body 如果出错, 当然的 promise 都需要被监听 @see com.relayrides.pushy.apns.ApnsClientHandler
            promiseCombiner.addAll(headersPromise, daraPromise);
            promiseCombiner.finish(promise);
            int finalStreamId = streamId;
            promise.addListener((GenericFutureListener<ChannelPromise>) future -> {
                if (future.isSuccess()) {
                    // todo success
                } else {
                    // todo fail (no retry)
                }
                logger.trace("message write end|{}|{}|{}", finalStreamId, future.isSuccess(), future.cause());
            });
        } else {
            super.write(ctx, msg, promise);
        }
    }

    /**
     * Returns true if the {@code streamId} is a valid HTTP/2 stream identifier.
     */
    public static boolean isStreamIdValid(int streamId) {
        return streamId >= 0;
    }

    public static Http2Headers prepareHeaders(Message message) {
        DefaultHttp2Headers headers = new DefaultHttp2Headers();

        if (message.header()!=null && !message.header().isEmpty()){

            message.header().getAll().forEach( );

        }

        headers.set()
        // todo
        return headers;
    }
}
