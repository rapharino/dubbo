package com.alibaba.dubbo.remoting.transport.http2.codec;

import io.netty.buffer.ByteBuf;

import java.util.HashMap;
import java.util.Map;

/**
 * Created By Rapharino on 2020/6/29 8:25 下午
 */
public interface Message {

    /**
     * message id == stream id
     *
     * @return
     */
    int id();

    /**
     * header
     *
     * @return
     */
    Header header();

    /**
     * data
     *
     * @return
     */
    ByteBuf data();

    /**
     * simple meta
     */
    class Header {
        Map<String, Object> holders = new HashMap<>();

        public boolean isEmpty() {
            return holders.isEmpty();
        }

        public Map<String, Object> getAll() {
            return holders;
        }
    }


    abstract class AbstractMessage implements Message {

        private int id;
        private Header header = new Header();
        private ByteBuf data;

        @Override
        public int id() {
            return this.id;
        }

        @Override
        public Header header() {
            return this.header;
        }

        @Override
        public ByteBuf data() {
            return this.data;
        }

        public void addHeader(String key, Object value) {
            this.header.holders.put(key, value);
        }

        public Object getHeader(String key) {
            return this.header.holders.get(key);
        }

    }
}
