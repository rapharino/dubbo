package com.alibaba.dubbo.remoting.transport.http2.codec;

/**
 * Created By Rapharino on 2020/7/1 5:01 下午
 */
public interface MessageReader {
    
}
