package com.alibaba.dubbo.remoting.transport.http2.codec;

/**
 * Created By Rapharino on 2020/6/29 8:24 下午
 * <p>
 * A stream to codec message
 *
 * @see Message
 */
public interface Stream {
    /**
     * get stream id
     */
    int getId();

    /**
     * write Message
     *
     * @return
     */
    Message write();

    /**
     * read Message
     *
     * @return
     */
    Message read();

    /**
     * is ready to get the Message
     *
     * @return
     */
    boolean readable();
}
