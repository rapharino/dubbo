package com.alibaba.dubbo.remoting.transport.http2.codec.message;

import com.alibaba.dubbo.remoting.transport.http2.codec.Message;

/**
 * Created By Rapharino on 2020/7/3 11:29 上午
 * <p>
 * the request message
 */
public class RequestMessage extends Message.AbstractMessage {

}
