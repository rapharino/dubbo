package com.alibaba.dubbo.remoting.transport.http2.codec.message;

import com.alibaba.dubbo.remoting.transport.http2.codec.Message;
import io.netty.buffer.ByteBuf;

/**
 * Created By Rapharino on 2020/7/3 11:29 上午
 * <p>
 * the response message
 */
public class ResponseMessage extends Message.AbstractMessage {

    public ResponseMessage(int id, Header header, ByteBuf data) {
        super(id, header, data);
    }



}
