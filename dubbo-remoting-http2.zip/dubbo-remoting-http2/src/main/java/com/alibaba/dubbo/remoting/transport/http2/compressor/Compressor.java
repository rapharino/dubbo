package com.alibaba.dubbo.remoting.transport.http2.compressor;

import com.alibaba.dubbo.remoting.transport.http2.codec.Message;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Created By Rapharino on 2020/7/1 5:01 下午
 * <p>
 * compressor the message from http2
 * @see Message
 */
public interface Compressor {
  /**
   *
   * @param os
   * @return
   * @throws IOException
   */
  OutputStream compress(OutputStream os) throws IOException;
}