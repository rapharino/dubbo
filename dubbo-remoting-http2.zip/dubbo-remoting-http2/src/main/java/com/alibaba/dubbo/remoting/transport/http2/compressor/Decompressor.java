package com.alibaba.dubbo.remoting.transport.http2.compressor;

import com.alibaba.dubbo.remoting.transport.http2.codec.Message;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created By Rapharino on 2020/7/1 5:01 下午
 * <p>
 * decompressor the message from http2
 * @see Message
 */
public interface Decompressor {

  /**
   * Decompressor
   * @param is
   * @return
   * @throws IOException
   */
  InputStream decompress(InputStream is) throws IOException;
}