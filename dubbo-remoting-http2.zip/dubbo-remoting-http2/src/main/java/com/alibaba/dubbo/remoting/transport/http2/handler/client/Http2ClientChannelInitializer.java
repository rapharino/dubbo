package com.alibaba.dubbo.remoting.transport.http2.handler.client;

import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.http2.HttpToHttp2ConnectionHandler;
import io.netty.handler.ssl.SslContext;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * Created By Rapharino on 2020/6/19 10:56 上午
 * channel initialize
 */
public class Http2ClientChannelInitializer extends ChannelInitializer<NioSocketChannel> {
    // ssl context
    protected SslContext sslCtx;

    public Http2ClientChannelInitializer() {
        this(null);
    }

    public Http2ClientChannelInitializer(SslContext sslCtx) {
        this.sslCtx = sslCtx;
    }

    /**
     * init channel
     *
     * @param ch
     * @throws Exception
     */
    @Override
    protected void initChannel(NioSocketChannel ch) throws Exception {
        final ChannelPipeline pipeline = ch.pipeline();
        if (sslCtx != null) {
            // ssl
            pipeline.addLast(sslCtx.newHandler(ch.alloc()));
            // todo: whit ssl protocol negotiation :  https/1.x  -> https/2
            throw new NotImplementedException();
        } else {
            pipeline.addLast(new Http2ClientHandler.Builder().build());

//            final Http2Connection connection = new DefaultHttp2Connection(false);
//            connectionHandler = new HttpToHttp2ConnectionHandlerBuilder()
//                    .frameListener(new DelegatingDecompressorFrameListener(
//                            connection,
//                            new InboundHttp2ToHttpAdapterBuilder(connection)
//                                    .maxContentLength(1024)
//                                    .propagateSettings(true)
//                                    .build()))
//                    .connection(connection)
//                    .build();
//
//            HttpClientCodec sourceCodec = new HttpClientCodec();
//            Http2ClientUpgradeCodec upgradeCodec = new Http2ClientUpgradeCodec(connectionHandler);
//            HttpClientUpgradeHandler upgradeHandler = new HttpClientUpgradeHandler(sourceCodec, upgradeCodec, 65536);
//            ch.pipeline().addLast(sourceCodec,
//                    upgradeHandler,
//                    new UpgradeRequestHandler());
        }
    }
}
