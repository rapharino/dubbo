package com.alibaba.dubbo.remoting.transport.http2.handler.client;

import com.alibaba.dubbo.remoting.transport.http2.codec.AbstractHttp2ConnectionHandler;
import io.netty.handler.codec.http2.AbstractHttp2ConnectionHandlerBuilder;
import io.netty.handler.codec.http2.Http2ConnectionDecoder;
import io.netty.handler.codec.http2.Http2ConnectionEncoder;
import io.netty.handler.codec.http2.Http2Settings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created By Rapharino on 2020/6/19 11:44 上午
 * <p>
 * http1&2 channel handler
 */
public class Http2ClientHandler extends AbstractHttp2ConnectionHandler {
    // LOGGER
    private static final Logger LOGGER = LoggerFactory.getLogger(Http2ClientHandler.class);

    public Http2ClientHandler(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings) {
        super(decoder, encoder, initialSettings);
    }

    public static class Builder extends AbstractHttp2ConnectionHandlerBuilder<Http2ClientHandler, Builder> {

        public Builder() {
            server(false);
        }

        @Override
        public Http2ClientHandler build() {
            return super.build();
        }

        @Override
        protected Http2ClientHandler build(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings) throws Exception {

            Http2ClientHandler handler = new Http2ClientHandler(decoder, encoder, initialSettings);
            return handler;
        }
    }
}