package com.alibaba.dubbo.remoting.transport.http2.handler.server;

import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.ssl.SslContext;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * Created By Rapharino on 2020/6/19 10:56 上午
 * channel initialize
 */
public class Http2ServerChannelInitializer extends ChannelInitializer<NioSocketChannel> {
    // ssl context
    protected SslContext sslCtx;

    public Http2ServerChannelInitializer() {
        this(null);
    }

    public Http2ServerChannelInitializer(SslContext sslCtx) {
        this.sslCtx = sslCtx;
    }

    /**
     * 条件初始化 channel
     *
     * @param ch
     * @throws Exception
     */
    @Override
    protected void initChannel(NioSocketChannel ch) throws Exception {
        final ChannelPipeline pipeline = ch.pipeline();
        if (sslCtx != null) {
            // ssl
            pipeline.addLast(sslCtx.newHandler(ch.alloc()));
            // todo protocol negotiation :  https/1.x  -> https/2
            throw new NotImplementedException();
        } else {
            //pipeline.addLast(Http2FrameCodecBuilder.forServer().build());
            pipeline.addLast(new Http2ServerHandler.Builder().build());

//            // protocol negotiation :  http/1.x  -> http/2
//            HttpServerCodec httpCodec = new HttpServerCodec();  // todo HttpServerCodec config
//            // Configure the pipeline for a `cleartext` upgrade from HTTP to HTTP/2.0
//            HttpServerUpgradeHandler httpUpgrade = new HttpServerUpgradeHandler(httpCodec, new HttpServerUpgradeHandler.UpgradeCodecFactory() {
//                @Override
//                public HttpServerUpgradeHandler.UpgradeCodec newUpgradeCodec(CharSequence protocol) {
//                    return new Http2ServerUpgradeCodec(
//                            Http2FrameCodecBuilder.forServer().build(),
//                            new Http2ServerHandler());
//                }
//            });
//
//            pipeline.addLast(new CleartextHttp2ServerUpgradeHandler(
//                    httpCodec, httpUpgrade, new Http2ServerHandler()));
        }
    }
}
