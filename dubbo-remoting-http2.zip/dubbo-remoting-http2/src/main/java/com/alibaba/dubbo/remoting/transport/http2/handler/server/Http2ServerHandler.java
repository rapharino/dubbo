package com.alibaba.dubbo.remoting.transport.http2.handler.server;

import com.alibaba.dubbo.remoting.transport.http2.codec.AbstractHttp2ConnectionHandler;
import io.netty.handler.codec.http2.AbstractHttp2ConnectionHandlerBuilder;
import io.netty.handler.codec.http2.Http2ConnectionDecoder;
import io.netty.handler.codec.http2.Http2ConnectionEncoder;
import io.netty.handler.codec.http2.Http2Settings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created By Rapharino on 2020/6/19 11:44 上午
 * <p>
 * http1&2 channel handler
 */
public class Http2ServerHandler extends AbstractHttp2ConnectionHandler {

    private static final Logger logger = LoggerFactory.getLogger(Http2ServerHandler.class);

    public Http2ServerHandler(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings) {
        super(decoder, encoder, initialSettings);
    }

    public static class Builder extends AbstractHttp2ConnectionHandlerBuilder<Http2ServerHandler, Builder> {

        public Builder() {
            server(true);
        }

        @Override
        public Http2ServerHandler build() {
            return super.build();
        }

        protected static int DEFAULT_FLOW_CONTROL_WINDOW = 1048576; // 1M

        @Override
        protected Http2ServerHandler build(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings) throws Exception {
            initialSettings.initialWindowSize(DEFAULT_FLOW_CONTROL_WINDOW);
            initialSettings.pushEnabled(false);
            Http2ServerHandler handler = new Http2ServerHandler(decoder, encoder, initialSettings);
            return handler;
        }
    }
}