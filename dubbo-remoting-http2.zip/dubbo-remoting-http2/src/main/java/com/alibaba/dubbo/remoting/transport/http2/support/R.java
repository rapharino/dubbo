package com.alibaba.dubbo.remoting.transport.http2.support;

import io.netty.util.AsciiString;

/**
 * Created By Rapharino on 2020/6/17 2:07 下午
 */
public final class R {

    /**
     * http/2 header names support for grpc
     */
    public static final class HeaderNames {
        /**
         * {@code "grpc-status"}.
         */
        public static final AsciiString GRPC_STATUS = AsciiString.cached("grpc-status");
        /**
         * {@code "grpc-message"}.
         */
        public static final AsciiString GRPC_MESSAGE = AsciiString.cached("grpc-message");
        /**
         * {@code "grpc-encoding"}.
         */
        public static final AsciiString GRPC_ENCODING = AsciiString.cached("grpc-encoding");
        /**
         * {@code "grpc-accept-encoding"}.
         */
        public static final AsciiString GRPC_ACCEPT_ENCODING = AsciiString.cached("grpc-accept-encoding");
        /**
         * {@code "grpc-timeout"}.
         */
        public static final AsciiString GRPC_TIMEOUT = AsciiString.cached("grpc-timeout");
    }
}
