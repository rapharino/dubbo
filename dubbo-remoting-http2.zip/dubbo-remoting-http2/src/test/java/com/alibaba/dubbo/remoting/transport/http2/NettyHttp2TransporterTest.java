/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alibaba.dubbo.remoting.transport.http2;

import com.alibaba.dubbo.common.Constants;
import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.remoting.Channel;
import com.alibaba.dubbo.remoting.RemotingException;
import com.alibaba.dubbo.remoting.Server;
import com.alibaba.dubbo.remoting.transport.ChannelHandlerAdapter;
import com.alibaba.dubbo.remoting.transport.http2.codec.message.RequestMessage;
import io.netty.handler.codec.http2.*;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class NettyHttp2TransporterTest {

    private static final URL url = new URL("http", "localhost", 8888,
            new String[]{Constants.BIND_PORT_KEY, String.valueOf(8888)});

    @Test
    public void server() throws Exception {
        Server server = new Http2Transporter().bind(url, new ChannelHandlerAdapter());
        assertThat(server.isBound(), is(true));
        Thread.sleep(Integer.MAX_VALUE);
    }


    @Test
    public void client() throws Exception {
        Http2Client client = (Http2Client) new Http2Transporter().connect(url, new ChannelHandlerAdapter(){
            @Override
            public void sent(Channel channel, Object message) throws RemotingException {
                System.out.println(channel+"sssss"+message);
                super.sent(channel, message);
            }

            @Override
            public void caught(Channel channel, Throwable exception) throws RemotingException {
                System.out.println(exception);
                super.caught(channel, exception);

            }
        });

        final DefaultHttp2Headers headers = new DefaultHttp2Headers();
        headers.method("GET");
        headers.path("/");
        headers.scheme("http");
        final Http2HeadersFrame headersFrame = new DefaultHttp2HeadersFrame(headers);

        RequestMessage a  = new RequestMessage();
        a.addHeader(":method","GET");
        a.addHeader(":path","GET");
        a.addHeader(":scheme","HTTP");

        for (;;){
            try {
               client.send(headersFrame);
            }catch (Error e){
                System.out.println(e);
            }finally {
                Thread.sleep(10L);
            }

        }

    }
//    @Test
//    public void shouldConnectToNetty4Server() throws Exception {
//        final CountDownLatch lock = new CountDownLatch(1);
//
//        int port = NetUtils.getAvailablePort();
//        URL url = new URL("http", "localhost", port,
//                new String[]{Constants.BIND_PORT_KEY, String.valueOf(port)});
//
//        new NettyTransporter().bind(url, new ChannelHandlerAdapter() {
//
//            @Override
//            public void connected(Channel channel) throws RemotingException {
//                lock.countDown();
//            }
//        });
//        new NettyTransporter().connect(url, new ChannelHandlerAdapter() {
//            @Override
//            public void sent(Channel channel, Object message) throws RemotingException {
//                channel.send(message);
//                channel.close();
//            }
//        });
//
//        lock.await();
//    }
}